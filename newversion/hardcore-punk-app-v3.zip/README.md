# DAMAGED: Hardcore Punk 1980-1999

Interactive dashboard covering two decades of hardcore punk, featuring 55+ bands, regional scene profiles, discography with streaming embeds, and AI-powered research.

## Architecture

```
hardcore-punk-dashboard/
├── public/
│   └── index.html          # Full dashboard (single HTML file)
├── api/
│   └── research.js         # Vercel serverless function (Claude AI proxy)
├── vercel.json              # Vercel configuration
├── package.json
└── README.md
```

## Features

- **Timeline**: Year-by-year history 1978-1999
- **Regional Scenes**: LA, DC, NYC, Boston, SF, Cleveland, UK
- **55+ Band Profiles**: Wikimedia photos, discographies, streaming links
- **Streaming Embeds**: Spotify, Apple Music, YouTube for every band
- **Related Bands**: "If you dig this, try..." recommendations
- **AI Research**: Biography, deep dives, scene context powered by Claude
- **Ask the Scene**: Free-form Q&A about hardcore punk history

## Deploy to Vercel

### 1. Deploy

```bash
cd hardcore-punk-dashboard
vercel --prod
```

### 2. Add Your Anthropic API Key

Go to your Vercel project dashboard:
**Settings > Environment Variables**

Add:
- **Key**: `ANTHROPIC_API_KEY`
- **Value**: Your Anthropic API key (get one at https://console.anthropic.com)
- **Environments**: Production, Preview

### 3. Redeploy

```bash
vercel --prod
```

The AI features will now work. Without the API key, the dashboard still functions perfectly for browsing, streaming, and exploring. The AI buttons will show a helpful error message pointing to the setup step.

## AI Research Endpoints

The `/api/research` serverless function supports these actions:

| Action | Description |
|--------|-------------|
| `biography` | Band history and significance |
| `deep_dive` | Sonic innovations, key shows, lesser-known facts |
| `scene_context` | City scene, peers, venues, labels |
| `find_images` | Creative Commons photo search strategies |
| `ask` | Free-form question about any band or scene |

## Tech Stack

- Vanilla HTML/CSS/JS (no framework, no build step)
- Vercel Serverless Functions (Node.js)
- Anthropic Claude API (claude-sonnet-4-20250514)
- Wikimedia Commons (band photos)
- Spotify/Apple Music/YouTube embeds
