// Vercel Serverless Function: /api/research
// Securely proxies requests to the Anthropic Claude API
// API key stored in Vercel environment variable ANTHROPIC_API_KEY

export default async function handler(request, response) {
  // CORS headers
  response.setHeader('Access-Control-Allow-Origin', '*');
  response.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  response.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (request.method === 'OPTIONS') {
    return response.status(200).end();
  }

  if (request.method !== 'POST') {
    return response.status(405).json({ error: 'Method not allowed' });
  }

  const apiKey = process.env.ANTHROPIC_API_KEY;
  if (!apiKey) {
    return response.status(500).json({ error: 'API key not configured. Add ANTHROPIC_API_KEY to Vercel environment variables.' });
  }

  try {
    const { action, bandName, query } = request.body;

    let prompt;
    let maxTokens = 1500;

    switch (action) {
      case 'biography':
        prompt = `You are a hardcore punk music historian and expert. Write a compelling, detailed biography of the band "${bandName}" focused on their history, significance, and legacy within the hardcore punk scene. Cover their formation, key members, musical evolution, important recordings, and cultural impact. Keep it factual and engaging. Write in a tone that respects the DIY ethos of the scene. 3-4 paragraphs, roughly 300-400 words. Do not use em dashes.`;
        break;

      case 'deep_dive':
        prompt = `You are a hardcore punk music historian. Provide a deep-dive analysis of "${bandName}" covering: 1) Their specific sonic innovations and how they differed from contemporaries, 2) Key live shows or tours that defined their reputation, 3) Lesser-known facts, controversies, or stories from their career, 4) Their lasting influence on subsequent bands and subgenres. Be specific with dates, venues, and names. 400-500 words. Do not use em dashes.`;
        maxTokens = 2000;
        break;

      case 'scene_context':
        prompt = `You are a hardcore punk historian. Explain the scene and cultural context around "${bandName}". What was happening in their city's hardcore scene when they formed? Who were their peers and rivals? What venues, labels, and zines were important to their development? How did they fit into the broader national hardcore network? 300-400 words. Do not use em dashes.`;
        break;

      case 'find_images':
        prompt = `You are a research assistant. I need to find Creative Commons or public domain photos of the hardcore punk band "${bandName}". Suggest 3-5 specific search strategies and URLs where free-to-use photos might be found. Include: 1) Specific Wikimedia Commons search URLs, 2) Flickr Creative Commons search URLs, 3) Any known free press photos or promotional images. Format as a JSON array of objects with "source", "url", and "description" fields. Return ONLY the JSON array, no other text.`;
        maxTokens = 800;
        break;

      case 'ask':
        prompt = `You are a hardcore punk music historian and expert, specializing in the 1980s and 1990s scenes. Answer this question knowledgeably and specifically: "${query}". Reference specific bands, albums, dates, venues, and people where relevant. If the question relates to a specific band, focus on "${bandName || 'the hardcore punk scene'}". Be conversational but authoritative. Do not use em dashes.`;
        maxTokens = 1500;
        break;

      default:
        return response.status(400).json({ error: 'Invalid action. Use: biography, deep_dive, scene_context, find_images, or ask' });
    }

    const anthropicResponse = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': apiKey,
        'anthropic-version': '2023-06-01'
      },
      body: JSON.stringify({
        model: 'claude-sonnet-4-20250514',
        max_tokens: maxTokens,
        messages: [
          { role: 'user', content: prompt }
        ]
      })
    });

    if (!anthropicResponse.ok) {
      const errText = await anthropicResponse.text();
      console.error('Anthropic API error:', anthropicResponse.status, errText);
      return response.status(502).json({
        error: 'AI service error',
        status: anthropicResponse.status,
        details: errText.substring(0, 200)
      });
    }

    const data = await anthropicResponse.json();
    const text = data.content
      .filter(item => item.type === 'text')
      .map(item => item.text)
      .join('\n');

    return response.status(200).json({
      result: text,
      action,
      bandName,
      model: data.model,
      usage: data.usage
    });

  } catch (err) {
    console.error('Server error:', err);
    return response.status(500).json({ error: 'Internal server error', message: err.message });
  }
}
